# How to run?

Run statik on the root of this example project to generate source code with directory contents.

	$ statik

Once the <projectPath>/statik package is generated, run the web server:

	$ go run main.go

Visit [http://localhost:8080/public/hello.txt](http://localhost:8080/public/hello.txt) to see the file.
